package ar.edu.unlp.objetos.uno.parcial1Fecha2022;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SistemaTest {
	private Sistema sistema;
	private Pedido sinItems;
	private Pedido conItems;

	
	@BeforeEach
	void setUp() {
		this.sistema= new Sistema();
		this.sinItems = sistema.darAltaPedidoExp("Olavarria", LocalDate.of(2022, 7, 31), "SRL SOLUCIONESAUTO");
		this.conItems= sistema.darAltaPedidoExp("La Plata", LocalDate.of(2022,6,31), "algo");
		conItems.agregarBien("maguera", 25, 50, 100 );
		conItems.agregarServicio("consultoria", 200, 100);
		
	}
	@Test
	void testGenerarFacturaPedido() {
		assertEquals(5800,this.sistema.generarFacturaPedido(conItems));
		assertNull(this.sistema.generarFacturaPedido(sinItems));
	}
}
