package ar.edu.unlp.objetos.uno.parcial1Fecha2022;
import java.time.LocalDate;
import java.util.List;
public class Factura {
	
	
	private LocalDate fechaF;
	private LocalDate fechaExp;
	private double costoBasico;
	private double costoExp;
	private double costoFinal;
	private List<Item> items;
	
	public Factura(LocalDate fechaExp, double costoBasico,List<Item> items) {
		this.fechaF = LocalDate.now();
		this.fechaExp = fechaExp;
		this.costoBasico = costoBasico;
		this.costoExp = this.getCostoBasico() *0.05;
		this.costoFinal = this.getCostoBasico() + this.getCostoExp();
		this.items = items;
	}
	public double getCostoExp() {
		return costoExp;
	}
	public double getCostoBasico() {
		return costoBasico;
	}
	public double getCostoFinal() {
		return costoFinal;
	}
	public LocalDate getFechaF() {
		return fechaF;
	}
}
