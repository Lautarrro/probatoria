package ar.edu.unlp.objetos.uno.parcial1Fecha2022;

public abstract class Item {
	private String descripcion;
	
	public Item(String descrip) {
		this.descripcion=descrip;
	}
	public abstract double getCostoBasico();
}
