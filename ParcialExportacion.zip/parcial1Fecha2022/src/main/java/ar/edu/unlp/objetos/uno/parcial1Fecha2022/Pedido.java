package ar.edu.unlp.objetos.uno.parcial1Fecha2022;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
public class Pedido {
	private String destino;
	private LocalDate fechaExp;
	private String name;
	private List<Item> items;
	
	public Pedido(String destino, LocalDate fechaExp, String name) {
		this.destino = destino;
		this.fechaExp = fechaExp;
		this.name = name;
		this.items = new ArrayList<Item>(); 
	}
	public void agregarBien(String descrip,int cant,double peso,double valor) {
		Bien b = new Bien(descrip,cant,peso,valor);
		this.items.add(b);
	}
	public void agregarServicio(String descrip,double costoMO,double costoM) {
		Servicio s = new Servicio(descrip,costoMO,costoM);
		this.items.add(s);
	}
	public double costoItems() {
		return this.items.stream()
				.mapToDouble(item -> item.getCostoBasico())
				.sum();
	}
	public Factura generarFactura() {
		Factura fact= new Factura(this.getFechaExp(),this.costoItems(),this.getItems());
		return fact;
	}
	public LocalDate getFechaExp() {
		return fechaExp;
	}
	public List<Item> getItems(){
		return this.items;
	}
}
