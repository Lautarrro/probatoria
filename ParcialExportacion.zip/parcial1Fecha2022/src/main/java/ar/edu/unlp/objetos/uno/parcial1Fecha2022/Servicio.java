package ar.edu.unlp.objetos.uno.parcial1Fecha2022;

public class Servicio extends Item {

	private double costoMO;
	private double costoM;
	
	public Servicio(String descrip, double costoMO, double costoM) {
		super(descrip);
		this.costoMO = costoMO;
		this.costoM = costoM;
	}
	
	public double getCostoMO() {
		return costoMO;
	}

	public double getCostoM() {
		return costoM;
	}
	@Override
	public double getCostoBasico(){
		return this.getCostoM() + this.getCostoMO();
	}
}
