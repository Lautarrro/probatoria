package ar.edu.unlp.objetos.uno.parcial1Fecha2022;

public class Bien extends Item {
	private int cant;
	private double valor;
	private double peso;
	
	public Bien(String descrip, int cant, double valor, double peso) {
		super(descrip);
		this.cant = cant;
		this.valor = valor;
		this.peso = peso;
	}
	protected boolean supera1KG() {
		return (this.getPeso() * this.getCant()) > 1000;
	}
	@Override
	public double getCostoBasico(){
		double costoBien =this.getValor() * this.getCant();
		if(supera1KG()) {
			return  (costoBien + (costoBien*0.10));
		}return costoBien;
	}
	public int getCant() {
		return cant;
	}
	public double getValor() {
		return valor;
	}
	public double getPeso() {
		return peso;
	}
}
