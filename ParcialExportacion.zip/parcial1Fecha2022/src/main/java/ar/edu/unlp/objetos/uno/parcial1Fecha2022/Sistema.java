package ar.edu.unlp.objetos.uno.parcial1Fecha2022;
import java.util.List;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.time.LocalDate;
public class Sistema {
	private List<Pedido> pedidos;
	private List<Factura> facturas;
	
	public Sistema() {
		this.pedidos= new ArrayList<Pedido>();
		
	}
	public Pedido darAltaPedidoExp(String destino,LocalDate fechaExp,String name) {
		Pedido ped = new Pedido(destino,fechaExp,name);
		this.pedidos.add(ped);
		return ped;
	}
	public void agregarBienAPedido(Pedido pedido,String descrip,int cant,double peso,double valor) {
		pedido.agregarBien(descrip,cant,peso,valor);
	}
	public void agregarServicioAPedido(Pedido pedido,String descrip,double costoMO,double costoM) {
 		pedido.agregarServicio(descrip,costoM,costoMO);
	}
	public Factura generarFacturaPedido(Pedido pedido) {
		if(pedido.getItems() != null) {
		Factura fact = pedido.generarFactura();
		this.facturas.add(fact);
		return fact;}
		return null;
	}
	 protected List<Factura> facturasEntreFechas(LocalDate f1,LocalDate f2){
		 return this.facturas.stream()
				 .filter(fact -> (fact.getFechaF().isAfter(f1) && fact.getFechaF().isBefore(f2)) || fact.getFechaF().equals(f1) || fact.getFechaF().equals(f1)) 
				 .collect(Collectors.toList());
	 }
	 public Factura facturaMayorCostoFinal(LocalDate f1, LocalDate f2) {
		 return this.facturasEntreFechas(f1, f2).stream()
				 .max((fact1,fact2) -> Double.compare(fact1.getCostoFinal(), fact2.getCostoFinal()))
				 .orElse(null);
	 }
}
