package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SistemaTest {
	private Sistema sistema;
	private Contribuyente user;
	private Bien inmueble;
	private Bien auto;
	private Bien barco;
	private Bien auto2;
	private Bien barco2;
	@BeforeEach
	void setUp() {
		this.sistema= new Sistema();
		this.user = sistema.darAltaContribuyente("lautaro", 31312, "mail@les", "Olavarria");
		this.auto=sistema.darAltaAutomotor(this.user, "22fs", "chevrolet", "corsa", LocalDate.of(2000, 1, 12), 200);
		this.auto2=sistema.darAltaAutomotor(this.user, "23fsa", "ford", "tes", LocalDate.of(2021, 2, 3),400);
		this.barco= sistema.darAltaEmbarcacion(this.user, "laritos", "11245", LocalDate.of(2010, 2, 21), 500);
		this.barco2= sistema.darAltaEmbarcacion(this.user, "lara", "145", LocalDate.of(2010, 2, 21), 1000200);
	}
	@Test
	void testCalcularImpuesto() {
		assertEquals(151093,this.sistema.calculoImpuesto(this.user));
	}
}
