package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Contribuyente {
	private List<Bien> bienes;
	private String name;
	private int dni;
	private String local;
	private String email;
	
	public Contribuyente(String name, int dni, String local, String email) {
		this.name = name;
		this.dni = dni;
		this.local = local;
		this.email = email;
		this.bienes= new ArrayList<Bien>();
	}
	public Inmueble agregarInmueble(int nroPartida,double valorL,double valorE) {
		Inmueble in= new Inmueble(nroPartida,valorL,valorE);
		this.bienes.add(in);
		return in;
	}
	public Transportador agregarAutomotor(String pat,String marca, String modelo, LocalDate fechaF,double valor) {
		Automotor auto= new Automotor(pat,valor,fechaF,marca,modelo);
		this.bienes.add(auto);
		return auto;
	}
	public Transportador agregarEmbarcacion(String pate,String name,LocalDate fechaF,double valor) {
		Embarcacion emb= new Embarcacion(pate,name ,fechaF,valor);
		this.bienes.add(emb);
		return emb;
}
	public double calcularImpuesto() {
		return this.bienes.stream()
				.mapToDouble(bien -> bien.calcularImp())
				.sum();
	}
	public String getLocal() {
		return this.local;
	}
}
