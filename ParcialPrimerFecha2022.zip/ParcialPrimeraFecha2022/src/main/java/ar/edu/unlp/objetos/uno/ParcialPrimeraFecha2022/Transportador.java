package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public abstract class Transportador implements Bien {

	private String patente;
	private double valor;
	private LocalDate fechaF;
	
	public Transportador(String patente, double valor, LocalDate fechaF) {
		this.patente = patente;
		this.valor = valor;
		this.fechaF = fechaF;
	}
	public double getValor() {
		return valor;
	}

	public LocalDate getFechaF() {
		return fechaF;
	}
	public boolean cantAnioFabricacion() {
		return (ChronoUnit.YEARS.between(this.getFechaF(),LocalDate.now())) >10;
	}
}
