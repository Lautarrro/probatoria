package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

public interface Bien {

	double calcularImp();
}
