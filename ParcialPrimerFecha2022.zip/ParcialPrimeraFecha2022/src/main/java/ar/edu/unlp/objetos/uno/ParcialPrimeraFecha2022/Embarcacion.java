package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

import java.time.LocalDate;

public class Embarcacion extends Transportador{
	private String nombre;
	
	public Embarcacion(String patente, String nombre,LocalDate fechaF,double valor) {
		super(patente, valor, fechaF);
		this.nombre = nombre;
	}
	@Override
	public double calcularImp() {
		if(!cantAnioFabricacion()) {
			if(this.getValor()>1000000)
				return this.getValor() *0.10;
			else
				return this.getValor() *0.15;
		}
		return 0;
	}
}
