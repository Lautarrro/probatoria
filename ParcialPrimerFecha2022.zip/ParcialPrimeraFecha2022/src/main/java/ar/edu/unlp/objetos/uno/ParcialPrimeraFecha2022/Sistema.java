package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Sistema {
	private List<Contribuyente> usuario;

	public Sistema() {
		this.usuario= new ArrayList<Contribuyente>();
		
	}
	public Contribuyente darAltaContribuyente(String name, int dni, String email,String local){
		Contribuyente c = new Contribuyente(name,dni,email,local);
		this.usuario.add(c);
		return c;
	}
	public Inmueble darAltaInmueble(Contribuyente user,int nroPartida,double valorLote, double valorEdif) {
		return user.agregarInmueble(nroPartida,valorLote,valorEdif);
	}
	public Transportador darAltaAutomotor(Contribuyente user,String pat,String marca,String modelo,LocalDate fechaF,double valor) {
		return user.agregarAutomotor(pat,marca,modelo,fechaF,valor);
	}
	public Transportador darAltaEmbarcacion(Contribuyente user,String nombre,String pat,LocalDate fechaF,double valor) {
		return user.agregarEmbarcacion(pat,nombre,fechaF,valor);
	}
	
	public double calculoImpuesto(Contribuyente user){
		return user.calcularImpuesto();
	}
	protected List<Contribuyente> usuarioLocalidad(String local){
		return this.usuario.stream()
				.filter(user -> user.getLocal().equals(local))
				.collect(Collectors.toList());
	}
	protected List<Contribuyente> usuarioQueMasPaga(String local){
		return this.usuarioLocalidad(local).stream()
				.sorted((c1,c2) -> Double.compare(c1.calcularImpuesto(), c2.calcularImpuesto()))
				.collect(Collectors.toList());
	}
	public List<Contribuyente> NUsuariosQueMasPagan(String local,int n){
		return this.usuarioQueMasPaga(local).stream().limit(n)
				.collect(Collectors.toList());
	}
}
