package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

public class Inmueble implements Bien{
	private int nroPartida;
	private double valorLote;
	private double valorEdif;
	
	public Inmueble(int nroPartida, double valorLote, double valorEdif) {
		this.nroPartida = nroPartida;
		this.valorLote = valorLote;
		this.valorEdif = valorEdif;
	}
	@Override
	public double calcularImp() {
		return (this.getValorEdif() + this.getValorLote())*0.01;
	}
	public double getValorLote() {
		return valorLote;
	}
	public double getValorEdif() {
		return valorEdif;
	}
}
