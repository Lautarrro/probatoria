package ar.edu.unlp.objetos.uno.ParcialPrimeraFecha2022;

import java.time.LocalDate;

public class Automotor extends Transportador{
	private String marca;
	private String modelo;
	
	public Automotor(String patente, double valor, LocalDate fechaF, String marca, String modelo) {
		super(patente, valor, fechaF);
		this.marca = marca;
		this.modelo = modelo;
	}
	@Override
	public double calcularImp() {
		if(!cantAnioFabricacion()) {
			return this.getValor() *0.05;
		}
		return 0;
	}
}
